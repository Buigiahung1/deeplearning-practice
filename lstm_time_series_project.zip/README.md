# LSTM Time-Series Forecasting Project

Dự án mô hình hóa dữ liệu chuỗi thời gian bằng mạng nơ-ron hồi quy LSTM (Long Short-Term Memory) triển khai bằng PyTorch.

## Cấu trúc File
- `main.py`: Mã nguồn chính chứa dữ liệu giả lập, định nghĩa mô hình, vòng lặp huấn luyện và đánh giá.
- `requirements.txt`: Các thư viện phụ thuộc.

## Yêu cầu môi trường
- Python >= 3.8
- PyTorch >= 1.12
- NumPy
- Matplotlib

## Hướng dẫn chạy
```bash
pip install -r requirements.txt
python main.py
```
